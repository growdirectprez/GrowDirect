<%
	// Retrieve the targeted coupons. 
	var cartTargetedCoupons = Session.MRStore.getTargetedIncentiveListByName(Session.sessionProfile, 'Registration', Session.visitorID, 1);

%>


<html>

<head>
  <title>Registration Confirmation</title>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" background="/tk/images/t_k4.jpg">
<table width="540" cellspacing="1" cellpadding="0">
  <tr>
  <td width="420" valign="middle"><font face="Tahoma" color="#0033ff"><b><font size="5"></font></b></font></td>
  <td width="120" valign="middle">&nbsp;&nbsp;&nbsp;<a target="main" href="home.jsp?<%=Session.Location.linkString()%>"><img src="/tk/images/buttons/home_button.gif" border="0"></a></td>
 </tr>  	
  <tr>
  <td colspan="2"><hr></td>
 </tr>
 <tr>
      <td>
	    <font size="2" face="Tahoma">Thank you for registering <%=currentVisitor().FIRST_NAME%>.  Click on the coupon below to add it to your wallet, 
         and save $10 on your purchases today.</font>, 
		</td>
    </tr>
    <tr>
    <td align="center">
     <%
function displayCoupons(){

// attach list of targeted coupons to Session
	Session.cartTargetedCoupons = cartTargetedCoupons;
	var couponCount =  cartTargetedCoupons == null ? 0 : cartTargetedCoupons.length;

    for (var i=0; i < couponCount; i++) {
        var coupon = cartTargetedCoupons.get(i);
	var isCoupon = (coupon.INCENTIVE_TYPE == 1);

        if (isCoupon) {	     
%>
        <A HREF="coupons.jsp?<%=Session.Location.linkString()%>&action=add&incentive_id=<%=coupon.INCENTIVE_ID%>&coupon_id=<%=coupon.COUPON_NO%>"><IMG SRC="<%=coupon.IMAGE_FILE%>"BORDER=0 HEIGHT=80 WIDTH=250></A>
      
<%
        } else {
%>
		<IMG SRC="<%=coupon.IMAGE_FILE%>" HEIGHT=80	WIDTH=250 ALT="Store-wide Sale">
		
<%
        }

    } // end of for loop body

	
}
%>
     </td>
     </tr>
      <tr> 
      <td>
	    <font face="Tahoma" size="2" color="#000000">At T&amp;K we take pride in offering
        our customers a personalized shopping experience. Help us get a better understanding of
        your needs and shopping preferences by filing out a customer profile. 
	    </font>
	  </td>
    </tr>
    <tr valign="top">
      <td colspan="2">
	    <FORM action="<%=Session.cgiinfo%>/tk/scripts/user_profile.jsp" method="post">
	      <%=Session.Location.formString()%>
		  <input type="image" name="submit" src="/tk/images/buttons/profile.gif" border="0">
		  </FORM>
	  </td>
    </tr>
    <tr>
      <td height="55">
	    <font face="Tahoma" size="2" color="#000000">If you just want to shop, click below.
        You can learn all about the services we offer our customers and more by visiting the<a
        href="<%=Session.cgiinfo%>/tk/scripts/my_account.jsp?<%=Session.Location.linkString()%>"> My Account</a> section of the website at anytime
	    </font>
	  </td>
    </tr>
    <tr valign="top">
      <td>
	    <FORM action="<%=Session.cgiinfo%>/tk/scripts/home.jsp" method="post">
	      <%=Session.Location.formString()%>
		  <input type="image" name="submit" value="submit" src="/tk/images/buttons/cont_shop.gif" border="0">
	    </FORM>
      </td>
	</tr>  
  </table>

<%
	displayCoupons();
%>
</body>
</html>


<%
function displayCoupons(){

// attach list of targeted coupons to Session
	Session.cartTargetedCoupons = cartTargetedCoupons;
	var couponCount =  cartTargetedCoupons == null ? 0 : cartTargetedCoupons.length;

    for (var i=0; i < couponCount; i++) {
        var coupon = cartTargetedCoupons.get(i);
	var isCoupon = (coupon.INCENTIVE_TYPE == 1);

        if (isCoupon) {	     
%>
        <TABLE>
			<TR>
				<TD> 
        <A HREF="coupons.jsp?<%=Session.Location.linkString()%>&action=add&incentive_id=<%=coupon.INCENTIVE_ID%>&coupon_id=<%=coupon.COUPON_NO%>"><IMG SRC="<%=coupon.IMAGE_FILE%>"BORDER=0 HEIGHT=80 WIDTH=250></A>
        		</TD>
<%
        } else {
%>
				<TD><IMG SRC="<%=coupon.IMAGE_FILE%>" HEIGHT=80	WIDTH=250 ALT="Store-wide Sale">
				</TD>
			<TR>
		</TABLE>
<%
        }

    } // end of for loop body

	
}
%>
