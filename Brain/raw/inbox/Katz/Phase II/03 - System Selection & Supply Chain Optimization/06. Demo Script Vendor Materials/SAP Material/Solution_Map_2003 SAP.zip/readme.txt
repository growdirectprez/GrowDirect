SAP SMART Download

Date:            10/22/2003 7:34:26 PM
User:            Janet Wright (i013060) 
# Files:         1

Asset #630
Retail Solution Map 2003
This Solution Map provides a consistent, multi-level blueprint showing processes for a company in the retail industry. It helps our customers visualize, plan, and implement a coherent, integrated and comprehensive information technology solution. The Solution Map also shows how various processes are covered, including the processes that SAP and its partners support. Use the Solution Composer (www.sap.com/businessmaps/s-composer) to assist customers to visualize and plan their own co-specific information technology solution. 
- 8444ENG_Global_Retail Solution Map 2003 (ppt).ppt (278 KB) 

