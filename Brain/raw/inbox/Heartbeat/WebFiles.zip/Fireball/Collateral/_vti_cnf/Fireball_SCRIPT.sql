vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|25 Apr 2001 20:39:01 -0000
vti_author:SR|NORTHAMERICA\\karengsa
vti_modifiedby:SR|NORTHAMERICA\\karengsa
vti_nexttolasttimemodified:TR|25 Apr 2001 20:39:01 -0000
vti_timecreated:TR|26 Apr 2001 02:14:16 -0000
vti_extenderversion:SR|5.0.2.2623
vti_syncwith_localhost\\c\:\\documents and settings\\karengsa\\my documents\\my webs\\fireball/c\:/documents and settings/karengsa/my documents/my webs/fireball:TR|25 Apr 2001 20:39:01 -0000
vti_lineageid:SR|{81A8F8FC-6F67-4D4D-ABF4-F5C5362624C9}
vti_cacheddtm:TX|26 Apr 2001 02:14:16 -0000
vti_filesize:IR|51062
vti_backlinkinfo:VX|
