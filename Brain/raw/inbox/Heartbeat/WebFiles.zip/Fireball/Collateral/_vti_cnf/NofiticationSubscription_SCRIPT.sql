vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|25 Apr 2001 20:38:34 -0000
vti_author:SR|NORTHAMERICA\\karengsa
vti_modifiedby:SR|NORTHAMERICA\\karengsa
vti_nexttolasttimemodified:TR|25 Apr 2001 20:38:34 -0000
vti_timecreated:TR|26 Apr 2001 02:14:17 -0000
vti_extenderversion:SR|5.0.2.2623
vti_syncwith_localhost\\c\:\\documents and settings\\karengsa\\my documents\\my webs\\fireball/c\:/documents and settings/karengsa/my documents/my webs/fireball:TR|25 Apr 2001 20:38:34 -0000
vti_lineageid:SR|{27A8A006-8D41-46DB-8305-06A9FF65623F}
vti_cacheddtm:TX|26 Apr 2001 02:14:17 -0000
vti_filesize:IR|140846
vti_backlinkinfo:VX|
