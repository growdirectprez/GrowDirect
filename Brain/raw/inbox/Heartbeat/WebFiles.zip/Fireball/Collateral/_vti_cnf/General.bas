vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|25 Apr 2001 20:38:55 -0000
vti_author:SR|NORTHAMERICA\\karengsa
vti_modifiedby:SR|NORTHAMERICA\\karengsa
vti_nexttolasttimemodified:TR|25 Apr 2001 20:38:55 -0000
vti_timecreated:TR|26 Apr 2001 02:14:16 -0000
vti_extenderversion:SR|5.0.2.2623
vti_syncwith_localhost\\c\:\\documents and settings\\karengsa\\my documents\\my webs\\fireball/c\:/documents and settings/karengsa/my documents/my webs/fireball:TR|25 Apr 2001 20:38:55 -0000
vti_lineageid:SR|{FD4B9A3A-1345-4A38-B528-676ECF3D432A}
vti_cacheddtm:TX|26 Apr 2001 02:14:16 -0000
vti_filesize:IR|2806
vti_backlinkinfo:VX|
