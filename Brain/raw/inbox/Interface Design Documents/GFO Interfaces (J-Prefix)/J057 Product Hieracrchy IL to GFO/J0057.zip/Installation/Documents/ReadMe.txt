This is the complete installation package excluding the the software.

Prerequisites :
Hardware Requirement / Machine Requirement

1. Operating System - Windows 2003 / XP
2. RAM - 2 GB 


Software Requirement
1. Internet Information Services
2. Visual Studio 2005
3. SQL Server 2005


Please read the "TOM_INTERFACE_J0057_implementation_notes.doc" for installation steps