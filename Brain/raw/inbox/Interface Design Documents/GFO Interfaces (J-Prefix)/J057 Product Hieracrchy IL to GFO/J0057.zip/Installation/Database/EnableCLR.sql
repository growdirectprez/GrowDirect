use [master]
GO

Exec Sp_Configure 'clr enabled' ,1
GO
Reconfigure
